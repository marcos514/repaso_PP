1- Para usar el servidor hay que tener instalado nodejs y mongoDB.
2- Pasos para iniciar el servidor:
    a- npm install
    b- npm start