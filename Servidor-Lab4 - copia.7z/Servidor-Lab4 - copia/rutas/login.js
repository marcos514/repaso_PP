const router = require("express").Router({mergeParams: true});
const jwt = require("jsonwebtoken");
let secret = "clave-hiper-mega-tera-peta-secreta";

router.post("/", async (req, res) => {
let o = req.body.cliente;
    if ( !o ) {
        res.json({error: "No encontrado objeto cliente"})
        return;
    }
    o.ip = req.ip;
    const clientes = req.db.collection("clientes");
    // let r = await clientes.find({user: o.name, pass: o.pass, ip: o.ip}).project({pass: 0, ip:0});
    // console.log(r);
    // res.json({rta: r.result});
    // return
    clientes
    .find({name: o.name, pass: o.pass, ip: o.ip})
    .project({ip: 0, pass: 0})
    .toArray( (err, data) => {
        if ( err ) {
            res.json({rta: err});
            return;
        }
        
        if ( data.length > 0 ) {
            //res.json({rta: data});
            
            try {
                let token = jwt.sign(data[0], secret);

                res.json({token: token});
                return;
            } catch (error) {
                res.json({error: error});
            }


            return;
        }
        res.json({error: "Credenciales invalidas"});
        
    });
});

module.exports = router;